import sys
import pygame
info_string = pygame.Surface((400, 30))

def check_events(ai_settings,screenhero,bands):
    """Обрабатывает нажатия клавиш и события мыши."""
    for event in pygame.event.get():
        if event.type== pygame.KEYDOWN:
            check_keydown_events(event,ai_settings,screen,hero)
        if event.type == pygame.QUIT:
            sys.exit()
        '''Событие-нажатие на клавишу'''
        if event.type == pygame.KEYDOWN:
            '''Передвижение игрока '''
            if event.key == pygame.K_LEFT:
                    if hero.x >= 10 and hero.x>=bands.x+40:
                        hero.x -= 4
                    elif (hero.x>=10 and hero.x>=bands.x+40):
                        hero.x-=4
                    elif (hero.y>bands.y or hero.y<bands.y):
                        hero.x-=1
                    
                    if hero.x>=10 and hero.x<=bands.x:
                        hero.x-=4
                    elif hero.x>=10 and hero.x<=bands.x:
                        hero.x-=4
                    elif (hero.y>bands.y or hero.y<bands.y):
                        hero.x-=1
                    
            '''Движение вправо'''
            if event.key == pygame.K_RIGHT:                  
                    if hero.x <= 1230 and hero.x+40<=bands.x :
                        hero.x +=4
                    elif (hero.x<=1230 and hero.x+40<=bands.x ):
                        hero.x+=4
                    elif (hero.y>bands.y or hero.y<bands.y):
                        hero.x+=1
                    if hero.x<=1230 and hero.x>=bands.x+40:
                        hero.x+=4
                    elif (hero.x<=1230 and hero.x>=bands.x+40 ):
                        hero.x+=4
                    elif (hero.y>bands.y or hero.y<bands.y):
                        hero.x+=1
            
                    
            if event.key == pygame.K_UP:
                        if hero.y > 400 :
                            hero.y -= 4
                        
            if event.key == pygame.K_DOWN:
                        if hero.y < 650 :
                            hero.y += 4
def update_screen(ai_settings, screen, hero,bands,hero_area,window):
     """Обновляет изображения на экране и отображает новый экран."""
    # При каждом проходе цикла перерисовывается экран.
    
     hero_area.fill((70, 70, 70))
     screen.blit(hero_area, (0, 400))
     bands.render()
     hero.render()
     window.blit(info_string, (0, 0))
     window.blit(screen, (0, 30))
     #pygame.display.flip()
     #pygame.time.delay(5)
     # Отображение последнего прорисованного экрана.
     pygame.display.flip()
