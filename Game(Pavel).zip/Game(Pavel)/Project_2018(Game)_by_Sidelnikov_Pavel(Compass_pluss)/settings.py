class Settings():
 """Класс для хранения всех настроек игры """
 def __init__(self):
     """Инициализирует настройки игры."""
     # Параметры экрана
     self.screen_width = 1270
     self.screen_height = 720
     self.bg_image = 'Image\Wall_03.png'
    
     
