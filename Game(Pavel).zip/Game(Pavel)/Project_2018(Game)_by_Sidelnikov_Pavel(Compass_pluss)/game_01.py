# -*- coding: utf-8 -*-
#
import pygame, sys
from livewires import games, color
from settings import Settings
import game_functions as gf
from pygame.sprite import Group

"""Инициализирует игру и создает обьект экрана."""
pygame.init()
window = pygame.display.set_mode((1270, 720))
pygame.display.set_caption('square battle')
#screen=pygame.image.load('Wall_03.png')
'''Строка состояния'''
info_string = pygame.Surface((400, 30))
'''Области движение'''
hero_area = pygame.Surface((1270,400))
ai_settings = Settings()
screen = pygame.display.set_mode((ai_settings.screen_width, ai_settings.screen_height))
screen=pygame.image.load(ai_settings.bg_image)
class Sprite:
    def __init__(self,xpos,ypos,filename):
        self.x=xpos
        self.y=ypos
        self.bitmap_origin=pygame.image.load(filename)
        self.bitmap = pygame.image.load(filename)
        self.set_colorkey(white)
        self.rect = self.bitmap_origin.get_rect()
        self.bitmap_origin.set_colorkey((0,0,0))
        self.bitmap.set_colorkey((0,0,0))

    def render(self):
        screen.blit(self.bitmap,(self.x,self.y))
class Hero(Sprite):
    def __init__(self,xpos,ypos,filename,screen):
        super().__init__(xpos,ypos,filename)
        self.screen=screen
        self.image = pygame.image.load('Image/h.png')

        self.rect = self.image.get_rect()
        self.screen_rect = screen.get_rect()
        self.rect.centerx = self.screen_rect.centerx
        self.rect.bottom = self.screen_rect.bottom
        #Флаг перемещиния 
        self.moving_right=False
    def update(self):
        '''бновляет позицию корабля с учетом флага'''
        if self.moving_right==True:
            self.x+=1
    def blitme(self):
        """Рисует корабль в текущей позиции."""
        self.screen.blit(self.image, self.rect)
'''Обьекты'''
hero=Hero(350,400,'h.png',screen)
bands=Sprite(700,700,'h.png')

done = True
pygame.key.set_repeat(1,1)
pygame.mouse.set_visible(False)
enumerator=0
'''Обработчик событий '''
while done:        
        gf.check_events(hero,bands)
        hero.update()
        bullets.update()
        gf.update_screen(ai_settings, screen, hero,bands,hero_area,window)
        
        pygame.time.delay(1)
        for e in pygame.event.get():
            if e.type == pygame.QUIT:
                sys.exit()
                done = False
        '''Движение противника'''
        if hero.x+40!=bands.x or hero.y+40!=bands.y:
                 if hero.x+40>bands.x:
                     bands.x+=1
                 
                 if hero.x-40<bands.x:
                     bands.x-=1
                 if hero.y>bands.y:
                     bands.y+=1
                 if hero.y<bands.y:
                     bands.y-=1
        
        '''Событие-нажатие на клавишу'''
        '''if e.type == pygame.KEYDOWN:
            Передвижение игрока 
            if e.key == pygame.K_LEFT:
                    if hero.x >= 10 and hero.x>=bands.x+40:
                        hero.x -= 2
                    elif (hero.x>=10 and hero.x>=bands.x+40):
                        hero.x-=2
                    elif (hero.y>bands.y or hero.y<bands.y):
                        hero.x-=1
                    
                    if hero.x>=10 and hero.x<=bands.x:
                        hero.x-=2
                    elif hero.x>=10 and hero.x<=bands.x:
                        hero.x-=2
                    elif (hero.y>bands.y or hero.y<bands.y):
                        hero.x-=1
                    
            Движение вправо
            if e.key == pygame.K_RIGHT:
                    if hero.x <= 1230 and hero.x+40<=bands.x :
                        hero.x += 2
                    elif (hero.x<=1230 and hero.x+40<=bands.x ):
                        hero.x+=2
                    elif (hero.y>bands.y or hero.y<bands.y):
                        hero.x+=1
                    if hero.x<=1230 and hero.x>=bands.x+40:
                        hero.x+=2
                    elif (hero.x<=1230 and hero.x>=bands.x+40 ):
                        hero.x+=2
                    elif (hero.y>bands.y or hero.y<bands.y):
                        hero.x+=1
                    
                    
            if e.key == pygame.K_UP:
                        if hero.y > 400 :
                            hero.y -= 2
                        
            if e.key == pygame.K_DOWN:
                        if hero.y < 650 :
                            hero.y += 2'''
                    

                 
        
        
        
        hero_area.fill((70, 70, 70))
        screen.blit(hero_area, (0, 400))
        bands.render()
        hero.render()
        window.blit(info_string, (0, 0))
        window.blit(screen, (0, 30))
        pygame.display.flip()
        pygame.time.delay(5)

