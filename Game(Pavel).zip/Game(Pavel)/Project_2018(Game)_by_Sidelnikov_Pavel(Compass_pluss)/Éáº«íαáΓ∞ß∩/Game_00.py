import math,random
from livewires import games,color

games.init(screen_width=640,screen_height=480,fps=60)

class Player():
    def update(self):
        
