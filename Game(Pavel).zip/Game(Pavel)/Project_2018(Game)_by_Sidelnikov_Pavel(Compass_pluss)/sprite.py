import pygame
from settings import Settings
from game_01 import *
class Sprite:
    def __init__(self,xpos,ypos,filename):
        self.x=xpos
        self.y=ypos
        self.bitmap_origin=pygame.image.load(filename)
        self.bitmap = pygame.image.load(filename)
        self.rect = self.bitmap_origin.get_rect()
        self.bitmap_origin.set_colorkey((0,0,0))
        self.bitmap.set_colorkey((0,0,0))

    def render(self):
        screen.blit(self.bitmap,(self.x,self.y))
