
# Pygame---Alien-Invasion
Arcade game i created with Python with classes and libraries and open source.

The game intails the space craft to shoot down incoming aliens and the counter keeps score. 

If alien encounters and shoots the player points get deducted.

- The game is a standard shooter where the player tries to avoid the lasers and fight back and get doubled the points.
- The ai is callobrated to make the player is equally challenged.
- Assert the collaberation of algorithms to make this work.
- Manipulating Data collected.

