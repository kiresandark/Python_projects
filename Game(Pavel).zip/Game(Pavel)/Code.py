import pygame,sys, os
from settings import Settings
from pygame.sprite import Group
from pygame.locals import *
import time
import random 

"""Инициализирует игру и создает обьект экрана."""
pygame.init()
window = pygame.display.set_mode((490, 580))
pygame.display.set_caption('Code')
'''Строка состояния'''
info_string = pygame.Surface((490, 490))
screen = pygame.Surface((490, 490))

#screen = pygame.display.set_mode((ai_settings.screen_width, ai_settings.screen_height))
#screen=pygame.image.load(ai_settings.bg_image)
class Menu:
    def __init__(self, punkts = [120, 140, u'Game', (250, 250, 30), (250, 30, 250), 0]):
        self.punkts = punkts
    def render(self, screen, font, num_punkt):
        for i in self.punkts:
            if num_punkt == i[5]:
                screen.blit(font.render(i[2], 1, i[4]), (i[0], i[1]-30))
            else:
                screen.blit(font.render(i[2], 1, i[3]), (i[0], i[1]-30))
    def menu(self):
        done = True
        pygame.mouse.set_visible(True)
        pygame.key.set_repeat(0,0)
        font_menu = pygame.font.Font('fonts/Purisa.otf', 50)
        punkt = 0
        while done:
            info_string.fill((0, 100, 200))
            screen.fill((0, 100, 200))
            
            mp = pygame.mouse.get_pos()
            for i in self.punkts:
                if mp[0]>i[0] and mp[0]<i[0]+155 and mp[1]>i[1] and mp[1]<i[1]+50:
                    punkt = i[5]
            self.render(screen, font_menu, punkt)
            
            for e in pygame.event.get():
                if e.type == pygame.QUIT:
                    sys.exit()
                if e.type == pygame.KEYDOWN:
                    if e.key == pygame.K_RETURN:
                        if punkt == 0:
                            done = False
                        if punkt == 1:
                            sys.exit()
                    if e.key == pygame.K_ESCAPE:
                        sys.exit()
                    if e.key == pygame.K_UP:
                        if punkt > 0:
                            punkt -= 1
                    if e.key == pygame.K_DOWN:
                        if punkt < len(self.punkts)-1:
                            punkt += 1
                if e.type == pygame.MOUSEBUTTONDOWN and e.button == 1:
                    if punkt == 0:
                        done = False
                    if punkt == 1:
                        sys.exit()
            
            window.blit(info_string, (0, 0))
            window.blit(screen, (0, 30))
            pygame.display.update()

class Sprite(pygame.sprite.Sprite):
    def __init__(self,xpos,ypos,filename):
        self.x=xpos
        self.y=ypos
        self.bitmap_origin=pygame.image.load(filename)
        self.bitmap = pygame.image.load(filename)
        self.rect = self.bitmap_origin.get_rect()
        self.bitmap_origin.set_colorkey((0,0,0))
        self.bitmap.set_colorkey((0,0,0))
        self.destroy=pygame.sprite.Sprite.kill

    def render(self):
        window.blit(self.bitmap,(self.x,self.y))
standarts=[]
lines1=[]
o2=0
standart=Sprite(0,0,'Standart.png')

# создание обычных точек 
for y in range(3):
    o=0
    for i in range(3):
            standart=Sprite(0,o2,'Standart.png')
            standart.x=o
            o+=210
            standarts.append(standart)
            print (standart.x,standart.y)
    o2+=210
o2=0
for i in range(3):
    o=70
    
    for i in range(2):
            line1=Sprite(0,o2,'Line_00.png')
            line1.x=o
            o+=210
            lines1.append(line1)
            print (line1.x,line1.y)
    o2+=210

line1_1=Sprite(0,70,'Line_01.png')
line2_1=Sprite(210,70,'Line_01.png')
line3_1=Sprite(420,70,'Line_01.png')
line4_1=Sprite(0,280,'Line_01.png')
line5_1=Sprite(210,280,'Line_01.png')
line6_1=Sprite(420,280,'Line_01.png')
line1_2=Sprite(70,70,'Line_02.png')
line2_2=Sprite(280,70,'Line_02.png')
line3_2=Sprite(70,280,'Line_02.png')
line4_2=Sprite(280,280,'Line_02.png')
line1_3=Sprite(70,70,'Line_03.png')
line2_3=Sprite(280,70,'Line_03.png')
line3_3=Sprite(70,280,'Line_03.png')
line4_3=Sprite(280,280,'Line_03.png')

# Здесь создаются оснвные элементы длля массива
hero=Sprite(0,420,'You.png')
x_list=[0,210,420]
done=True
kill=True
you=True
m=random.randint(0,8)
print(m)
bads=[]

for h in range(m):
    
    a=random.randint(0,2)
    b=random.randint(0,2)
    bad=Sprite(0,0,'Bad.png')
    bad.x=x_list[a]
    bad.y=x_list[b]
    bads.append(bad)
    print (bad.x,bad.y)
def lline():
    if hero.x>x or hero.y>y:
        print(8)
rty=0
zx=0
zy=0
br=0
''' создаем меню '''
punkts = [(120, 140, u'Start', (250, 250, 30), (250, 30, 250), 0),
          (130, 210, u'Quit', (250, 250, 30), (250, 30, 250), 1)]
game = Menu(punkts)
game.menu()
oxc=0
balls=0
call=0
bu=None
''' шрифты '''
pygame.font.init()
speed_font = pygame.font.Font(None, 32)
inf_font = pygame.font.Font(None, 32)
label_font = pygame.font.Font('fonts/OpenDyslexicAlta-Bold.otf', 30)
while done:
    
        pygame.time.delay(1)
        window.fill((70, 70, 70))
        for yu in range(9):
            standarts[yu].render()
        for yu in range(6):
            lines1[yu].render()
        
        line1_1.render()
        line2_1.render()
        line3_1.render()
        line4_1.render()
        line5_1.render()
        line6_1.render()
        line1_2.render()
        line2_2.render()
        line3_2.render()
        line4_2.render()
        line1_3.render()
        line2_3.render()
        line3_3.render()
        line4_3.render()
        
        for e in pygame.event.get():
            if e.type == pygame.QUIT:
                sys.exit()
                done = False
            if e.type== pygame.KEYDOWN:
                if e.key==pygame.K_LEFT :
                    kill=False
                    #os.system('cls')
                if e.key==pygame.K_KP1 or e.key==pygame.K_1:
                    if ((-zx+hero.x)<=210 and (hero.y-zy<=210)):
                        hero.x=0
                        hero.y=420
                        you=False
                    
                    rty+=1
                if e.key==pygame.K_KP2 or e.key==pygame.K_2:
                    hero.x=210
                    hero.y=420
                    you=False
                if e.key==pygame.K_KP3 or e.key==pygame.K_3:
                    
                    hero.x=420
                    hero.y=420
                    you=False
                if e.key==pygame.K_KP4 or e.key==pygame.K_4:
                    
                    hero.x=0
                    hero.y=210
                    
                    you=False
                if e.key==pygame.K_KP5 or e.key==pygame.K_5:
                    
                    hero.x=210
                    hero.y=210
                    you=False
                if e.key==pygame.K_KP6 or e.key==pygame.K_6:
                    
                    hero.x=420
                    hero.y=210
                    you=False
                if e.key==pygame.K_KP7 or e.key==pygame.K_7:
                    
                    hero.x=0
                    hero.y=0
                    you=False
                if e.key==pygame.K_KP8 or e.key==pygame.K_8:
                    
                    hero.x=210
                    hero.y=0
                    you=False
                if e.key==pygame.K_KP9 or e.key==pygame.K_9:
                
                    hero.x=420
                    hero.y=0
        
                    you=False
        for i in range(m):
            if hero.x!=bads[i].x and hero.y!=bads[i].y :
                if zx>hero.x or zx<hero.x or zy>hero.y or zy<hero.y:
                    if (hero.x-zx)>210 or(hero.x-zx)<210 :
                        if (hero.x-zx)>420 or (hero.x-zx)<420:
                            balls+=1
                        balls+=1
                    
                        
                    balls+=1
                    zx=hero.x
                    zy=hero.y
                    print('balls',balls)
        if hero.x==0 and hero.y==420:
            hero.render()
        if you==False:
            hero.render()
            you==True
        
        for g in range(m):
            bads[g].render()
            if hero.x==bads[g].x and hero.y==bads[g].y:  
                bads[g].bitmap=pygame.image.load('You.png')
                bads[g].x+=1
                ar='YESS'
                br+=1
                balls-=1
                print(ar,br)
                if br==m:
                    #print('You Win!')
                    
                    if balls<br:
                        bu='you win'
                        print(bu)
                    if balls>br:
                        bu='you lose'
                        print(bu)
                    if balls==br:
                        bu='Nothing'
                        print(bu)
                    balls=balls-br
                    print(balls)
                    
        ''' отрисовка шрифтов '''
        
        
        
        if br==m:
            punkts = [(214346570,12450,u'Quit',(0,0,0),(250,30,250),1),(130, 210, u'Quit', (250, 250, 30), (250, 30, 250), 1)]
            game = Menu(punkts)
            game.menu()
        info_string.blit(inf_font.render(u'Счет: '+str(balls), 1, (0, 250, 200)), (30, 0))
        
        info_string.blit(inf_font.render(u'You: '+str(bu), 1, (0, 250, 200)), (30, 50))
        #standart=Sprite(x,y,'Standart.png')
        #screen.blit(hero_area, (0, 400))
        window.blit(info_string, (0, 490))
        #window.blit(screen, (0, 490))
        pygame.display.flip()
        pygame.time.delay(5)

